//
//  ViewController.swift
//  SortArray
//
//  Created by Joana Valadao on 06/04/17.
//  Copyright © 2017 Joana Bittencourt. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    // MARK: Properties
    @IBOutlet weak var enter1: UITextField!
    @IBOutlet weak var enter2: UITextField!
    @IBOutlet weak var enter3: UITextField!
    @IBOutlet weak var enter4: UITextField!
    @IBOutlet weak var enter5: UITextField!
    
    @IBOutlet weak var result1: UITextField!
    @IBOutlet weak var result2: UITextField!
    @IBOutlet weak var result3: UITextField!
    @IBOutlet weak var result4: UITextField!
    @IBOutlet weak var result5: UITextField!
    
    @IBOutlet weak var intermediate: UITextView!
    
    
    // MARK: View Controller methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        enter1.delegate = self
        enter2.delegate = self
        enter3.delegate = self
        enter4.delegate = self
        enter5.delegate = self
        
        enter1.text = ""
        enter2.text = ""
        enter3.text = ""
        enter4.text = ""
        enter5.text = ""
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: Text Delegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    
    // Dismiss the text view keyboard, when the user types "Done"
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if text == "\n"  // Recognizes enter key in keyboard
        {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
    
    // MARK: Action
    @IBAction func sortArray(_ sender: UIButton) {
        // text field resign first responder
        enter1.resignFirstResponder()
        enter2.resignFirstResponder()
        enter3.resignFirstResponder()
        enter4.resignFirstResponder()
        enter5.resignFirstResponder()
        
        let e1 = Int(enter1.text ?? "0")
        let e2 = Int(enter2.text ?? "0")
        let e3 = Int(enter3.text ?? "0")
        let e4 = Int(enter4.text ?? "0")
        let e5 = Int(enter5.text ?? "0")
        
        
        var array = [e1, e2, e3, e4, e5]
        var intermed = ""
        
        // creating the background thread
        DispatchQueue.global(qos: DispatchQoS.userInitiated.qosClass).async {
            
            for i in 0...3 {
                for j in (i+1)...4 {
                    if array[i]! > array[j]! {
                        let element = array[i]
                        array[i] = array[j]
                        array[j] = element
                        
                        intermed += self.printArray(array as! [Int]) + "\n"
                        
                        //updating the user interface
                        DispatchQueue.main.async {
                            self.intermediate.text = intermed
                        } // main
                        
                        sleep(5)
                    } // if
                } // for - j
            } // for - i
        
            //updating the user interface
            DispatchQueue.main.async {
                self.result1.text = "\(array[0]!)"
                self.result2.text = "\(array[1]!)"
                self.result3.text = "\(array[2]!)"
                self.result4.text = "\(array[3]!)"
                self.result5.text = "\(array[4]!)"
            } //maind
        } // global
    } // sortArray
    
    
    // MARK: Private function
    func printArray(_ array : [Int]) -> String{
        var result = ""
        let count = array.count
        
        for i in 0..<count {
            result += "\(array[i])"
            if i < count-1 {
                result += " - "
            }
        }
        
        return result
    }

}

